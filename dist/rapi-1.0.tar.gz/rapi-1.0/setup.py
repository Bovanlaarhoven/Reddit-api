from setuptools import setup

setup(name='rapi',
    version='1.0',
    description='Erm reddit api wrapper',
    author='Bovanlaarhoven',
    zip_safe=False)
