from setuptools import setup

setup(name='redapi',
    version='1.0',
    description='Erm reddit api wrapper',
    author='Bovanlaarhoven',
    zip_safe=False)
